/****************************************************************************************
 ** Server is an application to manage several clients inside a thread.
 ** Copyright (C) 2013  Francesc Martinez <es.linkedin.com/in/cescmm/en>
 **
 ** This library is free software; you can redistribute it and/or
 ** modify it under the terms of the GNU Lesser General Public
 ** License as published by the Free Software Foundation; either
 ** version 2.1 of the License, or (at your option) any later version.
 **
 ** This library is distributed in the hope that it will be useful,
 ** but WITHOUT ANY WARRANTY; without even the implied warranty of
 ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 ** Lesser General Public License for more details.
 **
 ** You should have received a copy of the GNU Lesser General Public
 ** License along with this library; if not, write to the Free Software
 ** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 ***************************************************************************************/
 
#include "../inc/Client.h"
#include "../inc/mainwindow.h"

Client::Client(MainWindow* parent): qout(stdout), shutdownRequested(false),blockSize(0),m_socketStatus(0)
{
    m_mainWindow = parent;

    connect(this, SIGNAL(hostFound()), this, SLOT(OnHostFound()));
    connect(this, SIGNAL(readyRead()), this, SLOT(ProcessRequest()));
    connect(this, SIGNAL(sendRecvMessage(QByteArray*)),m_mainWindow,SLOT(MessageProcess(QByteArray*)));
//    connect(this, SIGNAL(error(QAbstractSocket::SocketError),this, SLOT(DisplayError(QAbstractSocket::SocketError))));
    //it need to be refined to handle with the exception
}
void Client::Start()
{
    connectToHost("127.0.0.1", 6666);
}
void Client::Stop()
{
    waitForBytesWritten(200);
    close();
}

void Client::OnHostFound()
{
    qout << "client: Found host!" << endl;
    QTimer::singleShot(5,this,SLOT(sendMessage1()));
    m_socketStatus = 1;
}

void Client::sendMessage(const QString& message)
{
   QByteArray block;
   QStringList msgToWrite;


   QString msg1="1234567890abcded";
   QString msg2="9876543210ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   QString msg3="1234567890abcded";

   msgToWrite.prepend(msg1);
   msgToWrite.prepend(msg2);
   msgToWrite.prepend(msg3);

   waitForReadyRead(3);
   for (int i = msgToWrite.size() - 1; i >= 0; i--)
   {
      block.append(msgToWrite.at(i).toLatin1());
      block.insert(0,(quint16)(block.size()));  //only insert 1 byte at here
      write(block);
      flush();
      msgToWrite.removeAt(i);
      block.clear();
    }

}


void Client::sendMessage1()
{
   QByteArray block;
   QStringList msgToWrite;


   QString msg1="1234567890abcded";
   QString msg2="9876543210ABCDEFGHIJKLMNOPQRSTUVWXYZ";
   QString msg3="1234567890abcded";

   msgToWrite.prepend(msg1);
   msgToWrite.prepend(msg2);
   msgToWrite.prepend(msg3);

   waitForReadyRead(3);
   for (int i = msgToWrite.size() - 1; i >= 0; i--)
   {
      block.append(msgToWrite.at(i).toLatin1());
      block.insert(0,(quint16)(block.size()));  //only insert 1 byte at here
      write(block);
      flush();
      msgToWrite.removeAt(i);
      block.clear();
    }

}

void Client::ProcessRequest(void)
{
    quint16 totalNum = 0;
    quint16 remaindNum = 0;
    int temp =0;
    QByteArray tmp;


    if (blockSize == 0)
    {
        if (this->bytesAvailable() < (int)sizeof(quint16))
            return;

        tmp = this->read(1);
        blockSize = tmp[0];
    }
    totalNum = this->bytesAvailable();
    if (totalNum < blockSize)
        return;
    QByteArray message(this->read(totalNum));
    remaindNum = this->bytesAvailable();
    sendRecvMessage(&message);
}

void Client::MessageProcess(QByteArray * message)
{

    QString msg(*(QByteArray*)message);
//    msg = QString::fromLocal8Bit(message->data(), message->size());
//      MessageContent->setText(msg);
    qDebug()<<"rece msg:"<<msg;
}

void Client::DisplayError(QAbstractSocket::SocketError socketError)
{
    switch (socketError)
    {
    case QAbstractSocket::RemoteHostClosedError:
        Stop();
        break;
    case QAbstractSocket::HostNotFoundError:
        qout << "client: The host was not found. Please check the host name and port settings." << endl;
        break;
    case QAbstractSocket::ConnectionRefusedError:
        qout << "client: The connection was refused by the peer. Make sure the fortune server is running,\n"
                "client: and check that the host name and port settings are correct." << endl;
        break;
    default:
       // qout << QString("client: The following error occurred: %1.").arg(tcpSocket->errorString()) << endl;
        break;
    }
}
