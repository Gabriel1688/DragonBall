/*
    Copyright (c) 2009-10 Qtrac Ltd. All rights reserved.

    This program or module is free software: you can redistribute it
    and/or modify it under the terms of the GNU General Public License
    as published by the Free Software Foundation, either version 3 of
    the License, or (at your option) any later version. It is provided
    for educational purposes and is distributed in the hope that it will
    be useful, but WITHOUT ANY WARRANTY; without even the implied
    warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See
    the GNU General Public License for more details.
*/


#include "../inc/mainwindow.h"
#include "../inc/fsm.h"
#include "../inc/sm.h"
#include "../inc/enquiry.h"
#include "../inc/Server.h"
#include "../inc/Client.h"
#include <QApplication>
#include <QtGui>
#include <QTimer>
#include <cmath>


// Can't use a QTimer because the interval between each iteration varies
// depending on how many items there are. So we use single shot timers
// instead

namespace {
const int DishSize = 10;
const int Margin = 20;
const int IterationDelay = 20;

//const int DishSize = 350;
//const int Margin = 20;
//const int IterationDelay = 50;

}


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), iterations(0), m_running(false)
{
    scene = new QGraphicsScene(this);
    scene->setItemIndexMethod(QGraphicsScene::NoIndex);

    createWidgets();
    createProxyWidgets();
    createLayout();
    createCentralWidget();

//    createCommThread();
    // deamond thread for backend commnication + thread pool for terminal management

    createStates();
    createTransitions();
    createConnections();

    setWindowTitle(tr("%1 (State Machine)").arg(QApplication::applicationName()));
    scene->invalidate();
    update();
//    m_client->Start();



    m_client = new Client(this);
 
    m_client->Start();
    
    m_commThread = new ClientThread(1,m_client);
    m_commThread->wait(2000);

    //create the terminal thread pool and related manager thread
    server = new Server(this);
    server->listen(QHostAddress::LocalHost,5555);
    rootServerThread = new QThread();
    connect(rootServerThread, SIGNAL(finished()), rootServerThread, SLOT(deleteLater()));
    server->moveToThread(rootServerThread);

    QTimer::singleShot(5, this, SLOT(start()));
 }


void MainWindow::createWidgets()
{
    chargerButton = new QPushButton(tr("C&harger"));
    binderButton = new QPushButton(tr("B&inder"));
    balanceButton = new QPushButton(tr("Bal&nce"));
    recordButton = new QPushButton(tr("R&ecord"));

    QString styleSheet("background-color: bisque;");
    ProcessLabel = new QLabel(tr("Current Process:"));
    ProcessLabel->setStyleSheet(styleSheet);
///
    MessageContentLabel = new QLabel(tr("Message Content:"));
    MessageContentLabel->setStyleSheet(styleSheet);

    MessageContent = new QLineEdit();
///
    initialCountLabel = new QLabel(tr("initial Count"));
    initialCountLabel->setStyleSheet(styleSheet);
    initialCountSpinBox = new QSpinBox;
    initialCountLabel->setBuddy(initialCountSpinBox);
    initialCountSpinBox->setAlignment(Qt::AlignVCenter|Qt::AlignRight);

    currentCountLabel = new QLabel(tr("Current count"));
    currentCountLabel->setStyleSheet(styleSheet);
    currentCountLCD = new QLCDNumber;
    currentCountLCD->setSegmentStyle(QLCDNumber::Flat);
    currentCountLCD->setStyleSheet(styleSheet);

    iterationsLabel = new QLabel(tr("Iterations"));
    iterationsLabel->setStyleSheet(styleSheet);
    iterationsLCD = new QLCDNumber;
    iterationsLCD->setSegmentStyle(QLCDNumber::Flat);
    iterationsLCD->setStyleSheet(styleSheet);

    showIdsCheckBox = new QCheckBox(tr("Show I&Ds"));
    showIdsCheckBox->setStyleSheet(styleSheet);
}
///
void MainWindow::createProxyWidgets()
{
    proxyForName["chargerButton"] = scene->addWidget(chargerButton);
    proxyForName["binderButton"] = scene->addWidget(binderButton);
    proxyForName["balanceButton"] = scene->addWidget(balanceButton);
    proxyForName["recordButton"] = scene->addWidget(recordButton);

    proxyForName["ProcessLabel"] = scene->addWidget(ProcessLabel);
    proxyForName["MessageContentLabel"] = scene->addWidget(MessageContentLabel);
    proxyForName["MessageContent"] = scene->addWidget(MessageContent);

    proxyForName["initialCountLabel"] = scene->addWidget(initialCountLabel);
    proxyForName["initialCountSpinBox"] = scene->addWidget(initialCountSpinBox);
    proxyForName["currentCountLabel"] = scene->addWidget(currentCountLabel);
    proxyForName["currentCountLCD"] = scene->addWidget(currentCountLCD);
    proxyForName["iterationsLabel"] = scene->addWidget(iterationsLabel);
    proxyForName["iterationsLCD"] = scene->addWidget(iterationsLCD);
    proxyForName["showIdsCheckBox"] = scene->addWidget(showIdsCheckBox);;
}


void MainWindow::createLayout()
{
    QGraphicsLinearLayout *leftLayout = new QGraphicsLinearLayout(Qt::Vertical);
    leftLayout->addItem(proxyForName["chargerButton"]);
    leftLayout->addItem(proxyForName["binderButton"]);
    leftLayout->addItem(proxyForName["balanceButton"]);
    leftLayout->addItem(proxyForName["recordButton"]);

    QGraphicsLinearLayout *rightLayout = new QGraphicsLinearLayout(Qt::Vertical);
    foreach (const QString &name, QStringList()
            << "ProcessLabel"
            << "initialCountLabel" << "initialCountSpinBox"
            << "currentCountLabel" << "currentCountLCD"
            << "iterationsLabel" << "iterationsLCD"
            << "showIdsCheckBox")
        rightLayout->addItem(proxyForName[name]);

    QGraphicsLinearLayout *bottomLayout = new QGraphicsLinearLayout(Qt::Vertical);
    bottomLayout->addItem(proxyForName["MessageContentLabel"]);
    bottomLayout->addItem(proxyForName["MessageContent"]);

    QGraphicsLinearLayout *layout = new QGraphicsLinearLayout;
    layout->addItem(leftLayout);
    layout->setItemSpacing(0, Margin);
    layout->addItem(rightLayout);
    layout->setItemSpacing(1,Margin);
    layout->addItem(bottomLayout);

    QGraphicsWidget *widget = new QGraphicsWidget;
    widget->setLayout(layout);
    scene->addItem(widget);

    int width = qRound(layout->preferredWidth());

//    int height = DishSize + (2 * Margin);
//    int height = 350 + (2 * Margin);
    int height = qRound(layout->preferredHeight()) + (2 * Margin);
    setMinimumSize(width, height);
    scene->setSceneRect(0, 0, width, height);
//    scene->setSceneRect(0, 0, width()-1, height()-1);

}


void MainWindow::createCentralWidget()
{

//    dishItem = new QGraphicsEllipseItem;
//    dishItem->setFlags(QGraphicsItem::ItemClipsChildrenToShape);
    dishItem = new QGraphicsRectItem;

    dishItem->setPen(QPen(QColor("brown"), 2.5));
    dishItem->setBrush(Qt::white);
//    dishItem->setRect(binderButton->width() + Margin, Margin, DishSize, DishSize);
//    dishItem->setRect(Margin,binderButton->height() * 4 + Margin*4, width()-1, height()-1);
    int width = Margin+ scene->width();
    int height = (binderButton->height()+ Margin)*5 + 200;
    dishItem->setRect(Margin,(binderButton->height()+ Margin)*5 ,width, height);

    scene->addItem(dishItem);

    view = new QGraphicsView(scene, this);
    view->setRenderHints(QPainter::Antialiasing|QPainter::TextAntialiasing);
    view->setBackgroundBrush(QColor("bisque"));
    setCentralWidget(view);
}


void MainWindow::createStates()
{

  m_smSM = new CSMFsm;
  m_smSM->Initialization();
  //initizalizae the property with this stateMachine.
  m_smSM->m_IdleState->assignProperty(showIdsCheckBox, "checked", true);
  m_smSM->m_IdleState->assignProperty(initialCountSpinBox, "minimum", 1);
  m_smSM->m_IdleState->assignProperty(initialCountSpinBox, "maximum", 100);
  m_smSM->m_IdleState->assignProperty(initialCountSpinBox, "value", 60);

//  m_smSM->m_waitLinkOKState->assignProperty(chargerButton, "enabled", false);
  m_smSM->m_waitLinkOKState->assignProperty(chargerButton, "enabled", true);

  m_smSM->m_waitLinkOKState->assignProperty(initialCountSpinBox, "enabled",false);


  m_enquirySM = new CENQUIRYFsm;
  m_enquirySM->Initialization();

  //initizalizae the property with this stateMachine.
  m_enquirySM->m_IdleState->assignProperty(showIdsCheckBox, "checked", true);
  m_enquirySM->m_IdleState->assignProperty(initialCountSpinBox, "minimum", 1);
  m_enquirySM->m_IdleState->assignProperty(initialCountSpinBox, "maximum", 100);
  m_enquirySM->m_IdleState->assignProperty(initialCountSpinBox, "value", 60);

//  m_enquirySM->m_waitLinkOKState->assignProperty(chargerButton, "enabled", false);
  m_enquirySM->m_waitLinkOKState->assignProperty(chargerButton, "enabled", true);

  m_enquirySM->m_waitLinkOKState->assignProperty(initialCountSpinBox, "enabled",false);

}


void MainWindow::createTransitions()
{
    /*
    initialState->addTransition(initialState,SIGNAL(propertiesAssigned()), stoppedState);
    stoppedState->addTransition(startButton, SIGNAL(clicked()),runningState);
    runningState->addTransition(pauseOrResumeButton,SIGNAL(clicked()), pausedState);
    runningState->addTransition(stopButton, SIGNAL(clicked()),stoppedState);
    pausedState->addTransition(pauseOrResumeButton,SIGNAL(clicked()), runningState);
    pausedState->addTransition(stopButton,SIGNAL(clicked()), stoppedState);
    normalState->addTransition(quitButton, SIGNAL(clicked()),finalState);
    */
}

void MainWindow::createConnections()
{
   //start different stateMachine according to the main screent menu
      connect(chargerButton, SIGNAL(clicked()),this, SLOT(chargerdProcess()));
      connect(balanceButton, SIGNAL(clicked()),this, SLOT(enquiryProcess()));
      connect(this,SIGNAL(machineStopped()),m_smSM,SLOT(stop()));
      connect(this,SIGNAL(machineStopped()),m_enquirySM,SLOT(stop()));

    /*
    connect(showIdsCheckBox, SIGNAL(toggled(bool)),this, SLOT(showIds(bool)));
    connect(runningState, SIGNAL(entered()), this, SLOT(start()));
    connect(pausedState, SIGNAL(entered()),  this, SLOT(pause()));
    connect(&stateMachine, SIGNAL(finished()), this, SLOT(close()));
    */
}


//-------------------//
void MainWindow::createCommThread()
{
    m_client = new Client(this);
    m_client->Start();
    int i = 0;
    while(m_client->m_socketStatus != 1)
    {
        for(i = 0; i < 1000; i++ )
          ;
    }
    m_commThread = new ClientThread(1,m_client);
    m_commThread->wait(2000);
}

//-------------------//

void MainWindow::showIds(bool show)
{
    scene->invalidate();
}


void MainWindow::closeEvent(QCloseEvent *event)
{
    setRunning(false);
    event->accept();
}

void MainWindow::chargerdProcess()
{
   if(m_smSM->isRunning())
   {
        qDebug()<<"enter the Charger Process";
        return;
   }

   //if current running statemachine isn't the chargerStateMahine, stop it.
   if(running())
   {
     emit machineStopped();
     setRunning(false);
   }
   else  //deal with the stateMachine Create or resume the stopped stateMachine.
   {
      m_smSM->run();
      setRunningFSM(m_smSM);
      setRunning(true);

      QTimer::singleShot(2,m_smSM, SLOT(Process()));
      QTimer::singleShot(20,m_smSM, SLOT(Process2()));
   }
   return;
}

void MainWindow::enquiryProcess()
{
    if(m_enquirySM->isRunning())
    {
         qDebug()<<"enter the enquiry Process";
         return;
    }
     //if current running statemachine isn't the chargerStateMahine, stop it.
    if(running())
    {
      emit machineStopped();
      setRunning(false);
    }
    else  //deal with the stateMachine Create or resume the stopped stateMachine.
    {
       m_enquirySM->run();
       setRunningFSM(m_enquirySM);
       setRunning(true);

       QTimer::singleShot(2,m_enquirySM, SLOT(Process()));
       QTimer::singleShot(20,m_enquirySM, SLOT(Process2()));
    }
}
void MainWindow::MessageProcess(QByteArray * message)
{

    QString msg(*(QByteArray*)message);
//    msg = QString::fromLocal8Bit(message->data(), message->size());
      MessageContent->setText(msg);
    qDebug()<<"rece msg:"<<msg;
}

void MainWindow::start()
{
    setWindowOpacity(1.0);
    iterationsLCD->display(iterations = 0);
    scene->invalidate();
    update();
//--copy from the server
    rootServerThread->start();


    QString option;
    QTextStream cout(stdout);
    QTextStream cin(stdin);

    for (int i = 0; i < 25; i++)
        cout<<endl;
    do
    {
        cout<<"# ";
        cout.flush();
        option = cin.readLine();

        if (option == "help")
        {
            cout<<endl<<endl;
            cout<<"Options:"<<endl<<endl;
            cout<<"v\tShows current server version."<<endl<<endl;
            cout<<"i id \n\tShows the client information of the specified client id."<<endl<<endl;
            cout<<"in name\n\tShows the client information of the specified client name."<<endl<<endl;
            cout<<"sa \tShow all clients."<<endl<<endl;
        }
//        if (option == "v")
//        {
//            cout<<endl;
//            cout<<QString("Server version %1\n").arg(VERSION_VS)<<endl;
//            cout.flush();
//        }
        else if (option == "sa")
        {
            cout<<endl;
            QList<Terminal*> clientList = server->getClients();

            if (clientList.size() > 0)
            {
                Terminal *client;

                cout<<"*-----------------------------------------------------*"<<endl;
                cout<<"|   CLIENT ID   |             CLIENT NAME             |"<<endl;
                cout<<"|-----------------------------------------------------|"<<endl;

                for (int i = 0; i < clientList.size(); i++)
                {
                    client = clientList.at(i);
                    if (client)
                    {
                        QString clientId = QVariant(client->getId()).toString();
                        QString clientName = client->getName();

                        int clIdSize = clientId.size();
                        for (int i = 0; i < 13 - clIdSize; i++)
                            clientId += " ";

                        int clNmSize = clientName.size();
                        for (int i = 0; i < 35 - clNmSize; i++)
                            clientName += " ";

                        cout<<QString("| %1 | %2 |").arg(clientId).arg(clientName)<<endl;
                    }
                }

                cout<<"*-----------------------------------------------------*"<<endl;
            }
            else
                cout<<"There are no clients connected."<<endl;
            cout<<endl;
        }
        else if (option.split(" ").at(0) == "i" or option.split(" ").at(0) == "in")
        {
            Terminal *client;

            if (option.split(" ").at(0) == "i")
            {
                int id = option.split(" ").at(1).toInt();
                client = server->getClient(id);
            }
            else
            {
                QString name = option.split(" ").at(1);
                client = server->getClientByName(name);
            }

            cout<<endl;

            if (client)
            {
                //First line
                cout<<"*-----------------------------------------------------*"<<endl;
                cout<<"|                     CLIENT INFO                     |"<<endl;
                cout<<"|-----------------------------------------------------|"<<endl;

                cout<<QString("| CLIENT ID     | %1 ").arg(client->getId());
                for (int i = 0; i < 35 - QVariant(client->getId()).toString().size(); i++)
                    cout<<" ";
                cout<<"|"<<endl;
                cout<<"|               |                                     |"<<endl;
                cout<<QString("| CLIENT NAME   | %1 ").arg(client->getName());
                for (int i = 0; i < 35 - client->getName().size(); i++)
                    cout<<" ";
                cout<<"|"<<endl;
                cout<<"|               |                                     |"<<endl;
                cout<<QString("| CLIENT IP     | %1 ").arg(client->getIpAddress());
                for (int i = 0; i < 35 - client->getIpAddress().size(); i++)
                    cout<<" ";
                cout<<"|"<<endl;
                cout<<"*-----------------------------------------------------*"<<endl;
            }
            else
                cout<<"There are no clients with this name."<<endl;

            cout<<endl;
        }
		else if (option.toInt() == 4)
			server->writeToClients("Test message...");
    }
    while (option != "quit" and option != "q");

//    QTimer::singleShot(IterationDelay, this, SLOT(doOneIteration()));
}


void MainWindow::doOneIteration()
{
    if (!running())
        return;
    int count = 0;
    scene->invalidate();
    iterationsLCD->display(++iterations);
    currentCountLCD->display(count);
    update();
    if (count <= 1)
        count = 100;
    else if (running())
        QTimer::singleShot(IterationDelay,this, SLOT(doOneIteration()));
}


void MainWindow::pause()
{
    setWindowOpacity(0.95);
    update();
}
