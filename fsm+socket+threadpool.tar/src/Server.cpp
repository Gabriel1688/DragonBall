/****************************************************************************************
 ** Server is an application to manage several clients inside a thread.
 ** Copyright (C) 2013  Francesc Martinez <es.linkedin.com/in/cescmm/en>
 **
 ** This library is free software; you can redistribute it and/or
 ** modify it under the terms of the GNU Lesser General Public
 ** License as published by the Free Software Foundation; either
 ** version 2.1 of the License, or (at your option) any later version.
 **
 ** This library is distributed in the hope that it will be useful,
 ** but WITHOUT ANY WARRANTY; without even the implied warranty of
 ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 ** Lesser General Public License for more details.
 **
 ** You should have received a copy of the GNU Lesser General Public
 ** License along with this library; if not, write to the Free Software
 ** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 ***************************************************************************************/

#include <QtCore>
#include "../inc/Server.h"
#include "../inc/terminal.h"
#include "../inc/terminalThread.h"
//#include "version.h"
#include "../inc/mainwindow.h"

Server::Server(QObject *parent) : QTcpServer(parent)
{
    m_mainWindow = (MainWindow*)parent;
}

Server::~Server()
{
}
void Server::RegisterSocketThread(Client* socketClient)
{
    m_socketClient = socketClient;
}

void Server::incomingConnection(int socketDescriptor)
{
    TerminalThread *client = new TerminalThread(socketDescriptor);
	connect(client, SIGNAL(receivedMessage(QString)), this, SLOT(processMsg(QString)));
	connect(client, SIGNAL(clientClosed(int)), this, SLOT(threadFinished(int)), Qt::DirectConnection);
	connect(client, SIGNAL(finished()), client, SLOT(deleteLater()));
//    connect(this,   SIGNAL(SendMessageToSocket(QString)),m_socketClient,SLOT(sendMessage(QString)), Qt::DirectConnection);

    connect(this,   SIGNAL(SendMessage1()),m_mainWindow,SLOT(chargerdProcess()), Qt::DirectConnection);


//    connect(this,   SIGNAL(SendMessage1()),m_socketClient,SLOT(sendMessage1()), Qt::DirectConnection);

    clientList.append(client);

	client->start();
}
void Server::terminalRegistration(const Protocol &msg,TerminalThread *clSender)
{
    Protocol clientsList;
    clientsList.setHeader(Protocol::CLIENTS_LIST);
    clientsList.setBody("List of connected clients");

    //TBD: register this new Terminal information in Local Database.

    //end of the comment
    SendMessageToSocket(clientsList.getFullMessage().toLatin1());
//    m_socketClient->sendMessage(clientsList.getFullMessage().toLatin1());
//    clSender->sendMessage(clientsList.getFullMessage().toLatin1());
}
//TerminalThread should be redirection to socket thread to send message to backend server.
void Server::routeBillingInfo(const Protocol &entity,TerminalThread *clSender)
{
    QString msg;
    //Step 1: decode the billing information
     entity.getOtherCommands().value("BillNUm").toString();
     entity.getOtherCommands().value("Value").toString();
    //Step 2: retrieve the TraceNo, Date, Time
       //we need to append the date/time/TraceNo  at the send level.

    //Step 3: construct a data package
       //
    //Step 4: post this package as message to socket thread

}
void Server::processMsg(const QString &msg)
{
    TerminalThread *clSender = (TerminalThread*)sender();

    //QLog_Trace("Server", "Received missage from client [" + clSender->getClient()->peerAddress().toString() + "]");

    Protocol protocol(msg);

    int type = protocol.getHeader();
    switch(type)
    {
      case Protocol::CLIENT_INFO:
        terminalRegistration(protocol,clSender);
        break;
      case Protocol::TERMINAL_REG:
        break;
      case Protocol::BILLING_INFO:
        break;
      case Protocol::CLIENT_EXIT:
        break;
     case Protocol::XML:
        break;
      default:
        break;
    }
/*
    if (protocol.getHeader() == Protocol::CLIENT_INFO)
    {
        Client *client = clSender->getClient();
        client->setName(protocol.getOtherCommands().value("name").toString());

        //Notify the clients that new one is connected and then the Server sends the client list to the new client
        Protocol newUser;
        newUser.setHeader(Protocol::NEW_CLIENT);
        newUser.setBody("New user has enter!");
        newUser.setOtherCommands("user", protocol.getOtherCommands().value("name").toString());

        Protocol clientsList;
        clientsList.setHeader(Protocol::CLIENTS_LIST);
        clientsList.setBody("List of connected clients");

        //we should register this new Terminal information in Local Database.

        for (int i = 0; i < clientList.size(); i++)
        {
            if (clientList.at(i)->getClient()->getId() != client->getId())
            {
                clientList.at(i)->sendMessage(newUser.getFullMessage().toLatin1());
                clientsList.setOtherCommands("user"+QVariant(clientList.at(i)->getClient()->getId()).toString(),clientList.at(i)->getClient()->getName());
            }
        }

        clSender->sendMessage(clientsList.getFullMessage().toLatin1());
        //client->waitForBytesWritten();
    }
    else if (protocol.getHeader() == Protocol::MULTICAST)
        multicastMsg(clSender->getClient(), protocol);
    else if (protocol.getHeader() == Protocol::MESSAGE)
        clientToClientMsg(protocol);
*/
}

void Server::clientToClientMsg(const Protocol &p)
{
    for (int i = 0; i < clientList.size(); i++)
    {
        if (clientList.at(i)->getClient()->getName() == p.getCommandValue("receiver") and p.getBody() != "")
        {
            clientList.at(i)->sendMessage(p.getFullMessage().toLatin1());
            //clientList.at(i)->waitForBytesWritten();
            break;
        }
    }
}

void Server::threadFinished(int threadId)
{
	QString userExited;

	for (int i = 0; i < clientList.size(); i++)
	{
		if (clientList.at(i)->getThreadId() == threadId)
		{
			userExited = clientList.at(i)->getClient()->getName();
			clientList.removeAt(i);
		}
	}

	//Message to the other clients
	Protocol *newUser = new Protocol();
	newUser->setHeader(Protocol::CLIENT_EXIT);
	newUser->setBody("User has left!");
	newUser->setOtherCommands("user", userExited);
	
	for (int i = 0; i < clientList.size(); i++)
		clientList.at(i)->sendMessage(newUser->getFullMessage().toLatin1());

	delete newUser;

//	QLog_Trace("Server", "Thread finished");
}

void Server::multicastMsg(Terminal *Terminal, const Protocol &p)
{
    if (Terminal != NULL)
	{
		Protocol *newMsg = new Protocol();
		newMsg->setHeader(Protocol::MESSAGE);
		newMsg->setBody(p.getBody());
        newMsg->setOtherCommands("sender", Terminal->getName());

//		QLog_Trace("Server", "Server message: " + p.getBody());

        for (int i = 0; i < clientList.size(); i++)
		{
            if (clientList.at(i)->getClient()->getId() != Terminal->getId())
				clientList.at(i)->sendMessage(newMsg->getFullMessage());
			else
			{
				Protocol *pAux = new Protocol();
				pAux->setHeader(Protocol::MESSAGE);
				pAux->setBody("Message sent!");
				pAux->setOtherCommands("sender","SERVER");
				clientList.at(i)->sendMessage(pAux->getFullMessage());
				delete pAux;
			}
		}
		delete newMsg;
	}
}

QList<Terminal*> Server::getClients() const
{
    QList<Terminal*> clients;

    for (int i = 0; i < clientList.size(); i++)
        clients.append(clientList.at(i)->getClient());

    return clients;
}

Terminal * Server::getClient(int _id) const
{
    for (int i = 0; i < clientList.size(); i++)
        if (clientList.at(i) and clientList.at(i)->getClient()->getId() == _id)
            return clientList.at(i)->getClient();

    return NULL;
}

Terminal * Server::getClientByName(const QString &_name) const
{
    for (int i = 0; i < clientList.size(); i++)
        if (clientList.at(i) and clientList.at(i)->getClient()->getName() == _name)
                return clientList.at(i)->getClient();

    return NULL;
}

void Server::writeToClients(const QString &_msg)
{
	for (int i = 0; i < clientList.size(); i++)
		clientList.at(i)->sendMessage(_msg.toLatin1());
}
