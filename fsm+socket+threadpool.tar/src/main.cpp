#include "../inc/fsm.h"
#include "../inc/sm.h"
#include "../inc/mainwindow.h"
#include <QApplication>
#include <QtGui>
#include <QStateMachine>
#include <QTime>

////----------implementation -----------////
int main(int argc, char** argv)
{
    QApplication a(argc,argv);
      //------create the SM stateMachine----------------//

    MainWindow window;
    window.show();
//    QObject::connect(&cmd, SIGNAL(quitApp()), &app, SLOT(quit()));
//    QTimer::singleShot(500, &cmd, SLOT(exec()));

    a.exec();
}
