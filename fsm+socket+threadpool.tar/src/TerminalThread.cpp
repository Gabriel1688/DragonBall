/****************************************************************************************
 ** Server is an application to manage several clients inside a thread.
 ** Copyright (C) 2013  Francesc Martinez <es.linkedin.com/in/cescmm/en>
 **
 ** This library is free software; you can redistribute it and/or
 ** modify it under the terms of the GNU Lesser General Public
 ** License as published by the Free Software Foundation; either
 ** version 2.1 of the License, or (at your option) any later version.
 **
 ** This library is distributed in the hope that it will be useful,
 ** but WITHOUT ANY WARRANTY; without even the implied warranty of
 ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 ** Lesser General Public License for more details.
 **
 ** You should have received a copy of the GNU Lesser General Public
 ** License along with this library; if not, write to the Free Software
 ** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 ***************************************************************************************/
 
#include <QDateTime>
//#include "version.h"
#include "../inc/terminal.h"
#include "../inc/terminalThread.h"



TerminalThread::TerminalThread(int _id, QObject *parent) : QThread(parent)
{
    socketId = _id;
	quit = false;
}

void TerminalThread::run()
{

    terminal = new Terminal(socketId);

    connect(terminal, SIGNAL(readyRead()), this, SLOT(readyRead()), Qt::DirectConnection);
    connect(terminal, SIGNAL(disconnected()), this, SLOT(disconnected()), Qt::DirectConnection);

    terminal->write("Welcome to the Server!");

    //QLog_Trace("TerminalThread", "New client from " + terminal->peerAddress().toString());

	while (!quit)
	{
        terminal->waitForReadyRead(1);
		for (int i = msgToWrite.size() - 1; i >= 0; i--)
		{
            terminal->write(msgToWrite.at(i).toLatin1());
			msgToWrite.removeAt(i);
		}
	}

}

void TerminalThread::readyRead()
{
    emit receivedMessage(terminal->readAll());
}

void TerminalThread::disconnected()
{
    emit clientClosed(socketId);

    terminal->deleteLater();

	quit = true;
}

void TerminalThread::sendMessage(const QString &msg)
{
    //QLog_Trace("TerminalThread", "TerminalThread::sendMessage()");
	msgToWrite.prepend(msg);
}
