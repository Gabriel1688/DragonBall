#ifndef SM_H
#define SM_H
#include "../inc/fsm.h"
#include "../inc/Client.h"
#include "../inc/ClientThread.h"

#include <QApplication>
#include <QtGui>
#include <QStateMachine>

class QStateMachine;
class CSMS_Idle;
class CSMS_WaitLinkOK;

class CSMFsm : public CFsm
{
    Q_OBJECT
public:
//attribute

//operator
    CSMFsm( QStateMachine* parent =0);
    virtual ~CSMFsm();
//implimentation

    int  MsgProc( MESSAGE* pmsg, int* pUser );
    int  Initialization();
    int  run();

    CSMS_WaitLinkOK* m_waitLinkOKState;
    CSMS_Idle* m_IdleState;

//    ClientThread* m_clientThread;
public slots:
    void Process();
    void Process2();
signals:

private:
//attribute

//operator
//    void Initialize();
//implimentation
//    virtual char* GetCurStateString(int nIndex) ;
};


class CSMS_Idle : public CState
{
Q_OBJECT
public:
//attribute
//operator
    CSMS_Idle(CFsm* parent);
    virtual ~CSMS_Idle();
    int   MsgProc( CFsm* pCtrl, MESSAGE* pmsg, int* UserID );
    void  StateProc(int index);
    void   OnSMM_Paging(CFsm* pCtrl, const MESSAGE* pmsg, int* pUser );
//implimentation
public slots:
    void Initialization();
signals:
    void move2WaitLinkOK();
private:
//attribute
       CSMFsm * m_pfsm;
//operator
//implimentation
};

class CSMS_WaitLinkOK : public CState
{
  Q_OBJECT
public:
//attribute
//operator
    CSMS_WaitLinkOK(CFsm* parent);
    virtual ~CSMS_WaitLinkOK();
    void  StateProc(int index);
//implimentation
    int MsgProc( CFsm* pCtrl, MESSAGE* pmsg, int* UserID );
public slots:
    void Initialization();
signals:
    void  move2Idle();
private:
//attribute
     CSMFsm * m_pfsm;
//operator
//implimentation

};

#endif // SM_H
