#ifndef MAINWINDOW_H
#define MAINWINDOW_H


//#include "cell.hpp"
#include "../inc/sm.h"
#include "../inc/enquiry.h"
#include "../inc/ClientThread.h"
#include "../inc/Client.h"
#include "../inc/Server.h"
#include "../inc/terminal.h"
#include "../inc/terminalThread.h"

#include <QHash>
#include <QList>
#include <QMainWindow>
#include <QStateMachine>
#include <QLineEdit>
#include <QGraphicsRectItem>
#include <QByteArray>

#ifndef M_PI
#define M_PI 3.14159265358
#endif

class QCheckBox;
class QFinalState;
class QGraphicsEllipseItem;
class QGraphicsScene;
class QGraphicsView;
class QLabel;
class QLCDNumber;
class QPushButton;
class QSpinBox;
class QState;
class QByteArray;


class MainWindow : public QMainWindow
{
    Q_OBJECT
    Q_PROPERTY(bool running READ running WRITE setRunning)

public:
    explicit MainWindow(QWidget *parent=0);
    CENQUIRYFsm* m_enquirySM;
    CSMFsm*  m_smSM;
    Client*  m_client;
    Server*  server;
    QThread* rootServerThread;
protected:
    void closeEvent(QCloseEvent *event);

private slots:
    void start();
    void pause();
    void doOneIteration();
    void showIds(bool show);
    void chargerdProcess();
    void enquiryProcess();
    void MessageProcess(QByteArray* message);


signals:
    void machineStopped();

private:
    void createWidgets();
    void createProxyWidgets();
    void createLayout();
    void createCentralWidget();
    void createStates();
    void createTransitions();
    void createConnections();

    void createCommThread();


    bool running() const { return m_running; }
    void setRunning(bool running) { m_running = running; }

    CFsm* runningFSM() const { return m_runningSM; }
    void setRunningFSM(CFsm* running) { m_runningSM = running; }

    //add by gabriel
    CFsm* m_runningSM;
    //end of comment
    QGraphicsView *view;
    QGraphicsScene *scene;
    QGraphicsRectItem *dishItem;

    QPushButton *chargerButton;
    QPushButton *binderButton;
    QPushButton *balanceButton;
    QPushButton *recordButton;

    QLabel      *ProcessLabel;
    QLabel      *MessageContentLabel;
    QLineEdit   *MessageContent;

    QLabel *initialCountLabel;
    QSpinBox *initialCountSpinBox;
    QLabel *currentCountLabel;
    QLCDNumber *currentCountLCD;
    QLabel *iterationsLabel;
    QLCDNumber *iterationsLCD;
    QCheckBox *showIdsCheckBox;
    QHash<QString, QGraphicsProxyWidget*> proxyForName;

    ClientThread* m_commThread;
    Client*       m_commClient;

    //QList<Cell*> cells;
    int iterations;
    bool m_running;
};

#endif // MAINWINDOW_H

