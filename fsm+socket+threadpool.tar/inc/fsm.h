/*************************************************************************/
/*                                                                       */
/*     Copyright (c) 2003-2009 xinwei Tech. Co., Ltd.                    */
/*                         All rights reserved.                          */
/*                                                                       */
/*                                                                       */
/*************************************************************************/

/************************************************************************

  filename:    FSM.h
  
    authors:    xinwei Tech. Co., Ltd.(hanqiyi)
    
      overview:    CUser header module.
      
        history of changes:
        
          rev            date        pgmr              change
          ----------------------------------------------------------------------
          
            1.00        08/20/2004    hanqiyi       Started.
            
***************************************************************************/
#ifndef _FSM_H_
#define _FSM_H_
#include "../inc/ClientThread.h"

#include <QStateMachine>
#include <QState>

/////--------------------------////

const int HANDLE_NO_END = -1;
const int RETURN_PARENT = -2;
const int HANDLE_END    =  0;
const int HANDLE_ERR    = -3;

typedef struct tagMESSAGE
{
    unsigned char    did;
    unsigned char    type;
    unsigned char    sid;
    unsigned char    length;
    union
    {
        unsigned char    content[256];
    }Union;
} MESSAGE;


/////-------------------------////



class CState;

/**********************************************************************
*  FUNTION: ����״̬����      
*  Author: hanqiyi        
*  Date:          
**********************************************************************/
class CFsm:public QStateMachine
{
    Q_OBJECT
//    Q_PROPERTY(CState* CurState READ curState WRITE setCurState)

public:
    CState* m_pCurState;  //��ǰ��״ָ̬��
    int m_nStateIndex;   //��¼״̬����ǰ������״̬����

    ClientThread* m_ClientThread;

    CFsm( QStateMachine* parent = 0);

    virtual ~CFsm();
  
    virtual int MsgProc( MESSAGE* pmsg , int* UserID = 0 );

    void setCurState(CState* state)
    {
        m_pCurState = state;
    }

    CState* curState()
    {
       return  m_pCurState;
    }

    CState* GetCurState()
    {
        return m_pCurState;
    };

    int GetCurStateIndex()      
    {
        return m_nStateIndex;
    };

    void SetStateHead( CState** ppStateHead )
    {
        m_ppStateHead = ppStateHead;
    };

    char* m_pstrStateName;
    //operator
    virtual void ChangeState( int StateType );          //�ı�״̬
    CState* finalState;
protected:
    //attribute
private:

    CState** m_ppStateHead;       //״̬������׵�ַָ��
 };
inline void CFsm::ChangeState( int StateType )
{
    m_nStateIndex = StateType;
}

/**********************************************************************
*  FUNTION: ����״̬��      
*  Author: hanqiyi        
*  Date:          
**********************************************************************/

class CState : public QState
{
public:
    CState(CFsm* stateMachine) ;
    virtual int MsgProc( CFsm* pCtrl, MESSAGE* pmsg, int* UserID );

    int HandleMsg( unsigned int message, long wParam = 0,  long lParam = 0,int* pUser = 0 );      //���Ϳؼ��¼�
    void ChangeState(  CFsm* pCtrl, int StateType );
    int  m_nErrorCount;

    virtual void  StateProc(int index) = 0;
protected:

private:
//attribute:
    int nStateInfo ;
    CFsm* m_pfsm;
};
#endif
