/****************************************************************************************
 ** Server is an application to manage several clients inside a thread.
 ** Copyright (C) 2013  Francesc Martinez <es.linkedin.com/in/cescmm/en>
 **
 ** This library is free software; you can redistribute it and/or
 ** modify it under the terms of the GNU Lesser General Public
 ** License as published by the Free Software Foundation; either
 ** version 2.1 of the License, or (at your option) any later version.
 **
 ** This library is distributed in the hope that it will be useful,
 ** but WITHOUT ANY WARRANTY; without even the implied warranty of
 ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 ** Lesser General Public License for more details.
 **
 ** You should have received a copy of the GNU Lesser General Public
 ** License along with this library; if not, write to the Free Software
 ** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 ***************************************************************************************/
#ifndef Server_H
#define Server_H
 
#include <QStringList>
#include <QTcpServer>
#include <QThread>
#include "terminalThread.h"
#include "Protocol.h"
#include "Client.h"

class Server : public QTcpServer
{
    Q_OBJECT

    public:
        Server(QObject *parent = 0);
        ~Server();

        Terminal * getClient(int _id) const;
        Terminal * getClientByName(const QString &_name) const;
        QList<Terminal*> getClients() const;
		void writeToClients(const QString &_msg);
        void RegisterSocketThread(Client* socketClient);

    protected:
        void incomingConnection(int socketDescriptor);

    private:
        QStringList fortunes;
        QList<TerminalThread*> clientList;
        Client* m_socketClient;
        MainWindow* m_mainWindow;
        void clientToClientMsg(const Protocol &p);

    private slots:
        void processMsg(const QString &msg);
        void threadFinished(int threadId);
        void multicastMsg(Terminal *terminal, const Protocol &p);
    signals:
        void SendMessageToSocket(QString);
        void SendMessage1();

private:
        void terminalRegistration(const Protocol &msg,TerminalThread* clSender);
        void routeBillingInfo(const Protocol &entity,TerminalThread *clSender);

};

#endif
