#include "../inc/fsm.h"
#include "../inc/sm.h"
#include "../inc/mainwindow.h"
#include <QApplication>
#include <QtGui>
#include <QStateMachine>
#include <QTime>

////----------implementation -----------////
int main(int argc, char** argv)
{
    QApplication a(argc,argv);
      //------create the SM stateMachine----------------//

    MainWindow window;
    window.show();

     //QState* m_pidleState
/*
    CSMFsm* stateMachine = new CSMFsm;

    //----------create the related state under this statemachine------------//
    CSMS_Idle* m_pidleState = new CSMS_Idle(stateMachine);
    CSMS_WaitLinkOK* m_pwaitlinkokState = new CSMS_WaitLinkOK(stateMachine);
    QFinalState* finalState = new QFinalState(stateMachine);

    stateMachine->addState(m_pwaitlinkokState);
    stateMachine->addState(m_pidleState);
    stateMachine->addState(finalState);

    m_pidleState->addTransition(m_pidleState,SIGNAL(move2WaitLinkOK()),m_pwaitlinkokState);
    m_pwaitlinkokState->addTransition(m_pwaitlinkokState,SIGNAL(move2Idle()),m_pidleState);

    m_pidleState->assignProperty(m_pidleState,"running",true);

    stateMachine->setInitialState(m_pidleState);
    stateMachine->start();

    QTimer::singleShot(2,stateMachine, SLOT(Process()));
    QTimer::singleShot(20,stateMachine, SLOT(Process2()));
*/
    a.exec();
}
