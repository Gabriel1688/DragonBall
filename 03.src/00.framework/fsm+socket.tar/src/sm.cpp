#include "../inc/sm.h"
#include "../inc/ClientThread.h"

CSMFsm::CSMFsm( QStateMachine* parent):CFsm(parent)
{
//    Initialize();
}

CSMFsm::~CSMFsm()
{

}

int CSMFsm::Initialization()
{
    //----------create the related state under this statemachine------------//
    m_IdleState = new CSMS_Idle(this);
    m_waitLinkOKState = new CSMS_WaitLinkOK(this);
    QFinalState* finalState = new QFinalState(this);

    addState(m_waitLinkOKState);
    addState(m_IdleState);
    addState(finalState);

    m_IdleState->addTransition(m_IdleState,SIGNAL(move2WaitLinkOK()),m_waitLinkOKState);
    m_waitLinkOKState->addTransition(m_waitLinkOKState,SIGNAL(move2Idle()),m_IdleState);
    setInitialState(m_IdleState);

}

int CSMFsm::run()
{
    m_IdleState->assignProperty(m_IdleState,"running",true);
    start();
}
int CSMFsm::MsgProc( MESSAGE* pmsg, int* pUser )
{

    qDebug()<< "CSMFsm::MsgProc";
    CState *pState = GetCurState();
    int ret = pState->MsgProc( this, pmsg, pUser );

    pState->StateProc(m_nStateIndex);
    return HANDLE_END;//祥婬輛虜袨怓儂腔default揭燴
}

void CSMFsm::Process()
 {
    int user = 0;

    MESSAGE msg;
    msg.type = 0x1;
    msg.Union.content[0] = 0x8;//

    qDebug()<<"msgType:n"<<msg.type;

    this->MsgProc(&msg,&user);

    return;
}

void CSMFsm::Process2()
 {
    int user = 0;

    MESSAGE msg;
    msg.type = 0x1;
    msg.Union.content[0] = 0x8;//

    qDebug()<<"msgType:n"<<msg.type;

    this->MsgProc(&msg,&user);

    return;
}

CSMS_Idle::~CSMS_Idle()
{

}

CSMS_Idle::CSMS_Idle(CFsm *parent):CState(parent)
{
    m_pfsm = (CSMFsm*)parent;
    connect(this,SIGNAL(propertiesAssigned()),this,SLOT(Initialization()));
}

void CSMS_Idle::Initialization()
{
    qDebug()<< "CSMS_Idle::Initialization";

    //set the current state of FSM
    m_pfsm->m_pCurState = (CState*)this;


    //initializatiation the local member
}
int CSMS_Idle::MsgProc( CFsm* pCtrl, MESSAGE* pmsg, int* UserID )
{


  qDebug()<< "CSMS_Idle::MsgProc";
  switch(pmsg->type)
  {
    case 0x1:
      OnSMM_Paging( pCtrl,  pmsg, UserID );
      break;
    case 0x2:
      break;
    default:
      break;
  }
 return 0;
}

void  CSMS_Idle::StateProc(int index)
{
  switch(index)
  {
    case 0x0:
        break;
    case 0x2:
        emit move2WaitLinkOK();
       break;
    case 0x3:
    default:
       break;
  }
  return ;
}

void CSMS_Idle::OnSMM_Paging(CFsm* pCtrl,const MESSAGE* pmsg, int* pUser )
{

    qDebug()<< "CSMS_Idle::OnSMM_Paging";

    unsigned char content[4] = {0};
    unsigned char type = 0;

    CSMFsm* pFsm = (CSMFsm*) pCtrl;

    type = pmsg->Union.content[0] &0x1f;

    MESSAGE msg;
    switch ( type )
     {
        //傻秏洘paging
        case 0x08://ACC_SMS:
            ChangeState( pCtrl, 2 );
            break;
        case 0x0c://ACC_NORMAL_G729PLUSB:
            ChangeState( pCtrl, 2 );
            msg.did = 0x1;
            msg.sid = 0x2;
            msg.type = 0x1;
            msg.length = 0x5;
//            pCtrl->m_ClientThread.sendMessage(msg);
             break;
        //祑都
        default:
            break;
        }

    return ;
}


///////////////////-------------------------------------///////////////////////////
CSMS_WaitLinkOK::CSMS_WaitLinkOK(CFsm *parent):CState(parent)
{
    m_pfsm = (CSMFsm*)parent;
    connect(this,SIGNAL(propertiesAssigned()),this,SLOT(Initialization()));
}

CSMS_WaitLinkOK::~CSMS_WaitLinkOK()
{

}

void  CSMS_WaitLinkOK::Initialization()
{
     qDebug()<< "CSMS_WaitLinkOK::Initialization";
    //set the current state of FSM
     m_pfsm->m_pCurState = (CState*)this;
     //initializatiation the local member
 return;
}

int CSMS_WaitLinkOK::MsgProc( CFsm* pCtrl, MESSAGE* pmsg, int* UserID )
{

  qDebug()<< "CSMS_WaitLinkOK::MsgProc";

  unsigned char type = pmsg->type;
  unsigned char ret = 0;
  switch(type)
  {
    case 0:
      break;
    case 1:
      ChangeState( pCtrl, 1 );
      break;
    case 2:
      break;
    default:
      ret = 0x1;
      break;
  }

  return ret;
}


void CSMS_WaitLinkOK::StateProc(int index)
{

  switch(index)
  {
    case 0x0:
        break;
    case 0x1:
        emit move2Idle();
       break;
    case 0x2:
    default:
       break;
  }
  return ;
}



