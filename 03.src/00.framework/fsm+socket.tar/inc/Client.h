/****************************************************************************************
 ** Server is an application to manage several clients inside a thread.
 ** Copyright (C) 2013  Francesc Martinez <es.linkedin.com/in/cescmm/en>
 **
 ** This library is free software; you can redistribute it and/or
 ** modify it under the terms of the GNU Lesser General Public
 ** License as published by the Free Software Foundation; either
 ** version 2.1 of the License, or (at your option) any later version.
 **
 ** This library is distributed in the hope that it will be useful,
 ** but WITHOUT ANY WARRANTY; without even the implied warranty of
 ** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 ** Lesser General Public License for more details.
 **
 ** You should have received a copy of the GNU Lesser General Public
 ** License along with this library; if not, write to the Free Software
 ** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 ***************************************************************************************/
 
#ifndef Client_H
#define Client_H

//#include "mainwindow.h"
#include <QTcpSocket>
#include <QTimer>
#include <QMap>
#include <QSet>
#include <QStringList>
#include <QHostAddress>
#include <QByteArray>
//#include <QScriptValue>

class MainWindow;
class Client : public QTcpSocket
{
   Q_OBJECT

public:
   Client(MainWindow* parent = 0);
   ~Client(){};
   void Start();
   void Stop();

   int m_socketStatus;
   MainWindow* m_mainWindow;

private slots:
   void OnHostFound();
   void ProcessRequest();
   void DisplayError(QAbstractSocket::SocketError socketError);
   void sendMessage();
signals:
   void sendRecvMessage(QByteArray* message);
private:
   QString CommandErrorResponse(QString cmd, QString msg);

   QTextStream qout;
   bool shutdownRequested;
   int blockSize;
};
#endif // Client_H
