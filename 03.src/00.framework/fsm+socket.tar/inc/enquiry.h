#ifndef ENQUIRY_H
#define ENQUIRY_H
#include "../inc/fsm.h"

#include "../inc/Client.h"
#include "../inc/ClientThread.h"

#include <QApplication>
#include <QtGui>
#include <QStateMachine>

class QStateMachine;
class CENQUIRYS_Idle;
class CENQUIRYS_WaitLinkOK;

class CENQUIRYFsm : public CFsm
{
    Q_OBJECT
public:
//attribute

//operator
    CENQUIRYFsm( QStateMachine* parent =0);
    virtual ~CENQUIRYFsm();
//implimentation

    int  MsgProc( MESSAGE* pmsg, int* pUser );
    int  Initialization();
    int  run();

    CENQUIRYS_WaitLinkOK* m_waitLinkOKState;
    CENQUIRYS_Idle* m_IdleState;

    Client* m_Client;
    ClientThread* m_clientThread;
public slots:
    void Process();
    void Process2();
signals:

private:
//attribute

//operator
//    void Initialize();
//implimentation
//    virtual char* GetCurStateString(int nIndex) ;
};


class CENQUIRYS_Idle : public CState
{
Q_OBJECT
public:
//attribute
//operator
    CENQUIRYS_Idle(CFsm* parent);
    virtual ~CENQUIRYS_Idle();
    int   MsgProc( CFsm* pCtrl, MESSAGE* pmsg, int* UserID );
    void  StateProc(int index);
    void   OnSMM_Paging(CFsm* pCtrl, const MESSAGE* pmsg, int* pUser );
//implimentation
public slots:
    void Initialization();
signals:
    void move2WaitLinkOK();
private:
//attribute
       CENQUIRYFsm * m_pfsm;
//operator
//implimentation
};

class CENQUIRYS_WaitLinkOK : public CState
{
  Q_OBJECT
public:
//attribute
//operator
    CENQUIRYS_WaitLinkOK(CFsm* parent);
    virtual ~CENQUIRYS_WaitLinkOK();
    void  StateProc(int index);
//implimentation
    int MsgProc( CFsm* pCtrl, MESSAGE* pmsg, int* UserID );
public slots:
    void Initialization();
signals:
    void  move2Idle();
private:
//attribute
     CENQUIRYFsm * m_pfsm;
//operator
//implimentation

};

#endif // ENQUIRY_H
